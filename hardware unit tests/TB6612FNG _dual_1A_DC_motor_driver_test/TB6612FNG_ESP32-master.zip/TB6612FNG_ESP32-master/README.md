# TB6612FNG_ESP32
Sparkfun library adapted for working on esp32

Source:
https://github.com/sparkfun/SparkFun_TB6612FNG_Arduino_Library
https://github.com/vincasmiliunas/ESP32-Arduino-TB6612FNG
